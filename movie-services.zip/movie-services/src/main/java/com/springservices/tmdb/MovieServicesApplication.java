package com.springservices.tmdb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieServicesApplication.class, args);
	}

}
